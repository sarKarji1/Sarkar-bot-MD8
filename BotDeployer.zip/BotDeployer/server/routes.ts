import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertBotSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";
import axios from "axios";

// Heroku API helper functions
async function createHerokuApp(appName: string, apiToken: string) {
  try {
    const response = await axios.post(
      'https://api.heroku.com/apps',
      {
        name: appName,
        stack: 'heroku-22'
      },
      {
        headers: {
          'Authorization': `Bearer ${apiToken}`,
          'Accept': 'application/vnd.heroku+json; version=3',
          'Content-Type': 'application/json'
        }
      }
    );
    return response.data;
  } catch (error: any) {
    if (error.response?.status === 422 && error.response?.data?.message?.includes('Name is already taken')) {
      throw new Error(`App name "${appName}" is already taken. Please choose a different name.`);
    }
    throw new Error(`Failed to create Heroku app: ${error.response?.data?.message || error.message}`);
  }
}

async function setHerokuConfigVars(appName: string, configVars: Record<string, string>, apiToken: string) {
  try {
    await axios.patch(
      `https://api.heroku.com/apps/${appName}/config-vars`,
      configVars,
      {
        headers: {
          'Authorization': `Bearer ${apiToken}`,
          'Accept': 'application/vnd.heroku+json; version=3',
          'Content-Type': 'application/json'
        }
      }
    );
  } catch (error: any) {
    throw new Error(`Failed to set config vars: ${error.response?.data?.message || error.message}`);
  }
}

async function deployFromGithub(appName: string, repoUrl: string, apiToken: string) {
  try {
    // Extract owner and repo from GitHub URL
    const match = repoUrl.match(/github\.com\/([^\/]+)\/([^\/\.]+)/);
    if (!match) {
      throw new Error('Invalid GitHub repository URL');
    }
    
    const [, owner, repo] = match;

    // Create GitHub source
    const sourceResponse = await axios.post(
      `https://api.heroku.com/apps/${appName}/sources`,
      {},
      {
        headers: {
          'Authorization': `Bearer ${apiToken}`,
          'Accept': 'application/vnd.heroku+json; version=3',
          'Content-Type': 'application/json'
        }
      }
    );

    // Build the app from GitHub
    const buildResponse = await axios.post(
      `https://api.heroku.com/apps/${appName}/builds`,
      {
        source_blob: {
          url: sourceResponse.data.source_blob.get_url,
          version: 'main'
        }
      },
      {
        headers: {
          'Authorization': `Bearer ${apiToken}`,
          'Accept': 'application/vnd.heroku+json; version=3',
          'Content-Type': 'application/json'
        }
      }
    );

    return buildResponse.data;
  } catch (error: any) {
    throw new Error(`Failed to deploy from GitHub: ${error.response?.data?.message || error.message}`);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Bot management routes
  app.get("/api/bots", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const bots = await storage.getAllBots();
      res.json(bots);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bots" });
    }
  });

  app.post("/api/bots", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Admin access required" });
      }

      const validatedData = insertBotSchema.parse(req.body);
      const bot = await storage.createBot(validatedData);
      res.status(201).json(bot);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid bot data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create bot" });
    }
  });

  app.put("/api/bots/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Admin access required" });
      }

      const validatedData = insertBotSchema.parse(req.body);
      const bot = await storage.updateBot(req.params.id, validatedData);
      
      if (!bot) {
        return res.status(404).json({ message: "Bot not found" });
      }

      res.json(bot);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid bot data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update bot" });
    }
  });

  app.delete("/api/bots/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Admin access required" });
      }

      const success = await storage.deleteBot(req.params.id);
      
      if (!success) {
        return res.status(404).json({ message: "Bot not found" });
      }

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete bot" });
    }
  });

  // Deployment routes
  app.post("/api/deploy", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const { botId, appName, configValues } = req.body;
      
      if (!botId || !appName || !configValues) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      // Get the bot details
      const bot = await storage.getBot(botId);
      if (!bot) {
        return res.status(404).json({ message: "Bot not found" });
      }

      // Check user's deployment limit
      const userDeployments = await storage.getUserDeployments(req.user!.id);
      if (userDeployments.length >= req.user!.botLimit) {
        return res.status(403).json({ message: "Bot deployment limit reached" });
      }

      // Validate app name (Heroku naming requirements)
      const appNameRegex = /^[a-z][a-z0-9-]{2,29}$/;
      if (!appNameRegex.test(appName)) {
        return res.status(400).json({ 
          message: "Invalid app name. Must be 3-30 characters, start with a letter, and contain only lowercase letters, numbers, and hyphens." 
        });
      }

      const apiToken = process.env.HEROKU_API_TOKEN;
      if (!apiToken) {
        return res.status(500).json({ message: "Heroku API token not configured" });
      }

      try {
        // Step 1: Create Heroku app
        const herokuApp = await createHerokuApp(appName, apiToken);
        
        // Step 2: Set config variables
        await setHerokuConfigVars(appName, configValues, apiToken);
        
        // Step 3: Deploy from GitHub (if repo URL is provided)
        if (bot.repoUrl && bot.repoUrl.includes('github.com')) {
          await deployFromGithub(appName, bot.repoUrl, apiToken);
        }

        const appUrl = herokuApp.web_url || `https://${appName}.herokuapp.com`;

        // Create deployment record with actual URL and Heroku data
        const deployment = await storage.createDeployment({
          userId: req.user!.id,
          botId: botId,
          appName: appName,
          configUsed: configValues,
          url: appUrl,
          herokuAppId: herokuApp.id,
          status: "deployed"
        });

        res.status(201).json({
          ...deployment,
          message: "Bot deployed successfully to Heroku"
        });
      } catch (deployError: any) {
        console.error("Heroku deployment error:", deployError);
        
        // If it's an app name conflict, give specific error
        if (deployError.message.includes('already taken')) {
          return res.status(409).json({ message: deployError.message });
        }
        
        res.status(500).json({ 
          message: `Deployment failed: ${deployError.message}` 
        });
      }
    } catch (error) {
      console.error("Deployment error:", error);
      res.status(500).json({ message: "Failed to deploy bot" });
    }
  });

  app.get("/api/deployments", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const deployments = await storage.getUserDeployments(req.user!.id);
      res.json(deployments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch deployments" });
    }
  });

  // User management routes (admin only)
  app.get("/api/users", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Admin access required" });
      }

      const users = await storage.getAllUsers();
      res.json(users.map(user => ({ ...user, password: undefined })));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Admin access required" });
      }

      const validatedData = insertUserSchema.partial().parse(req.body);
      const user = await storage.updateUser(req.params.id, validatedData);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({ ...user, password: undefined });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.delete("/api/users/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Admin access required" });
      }

      const success = await storage.deleteUser(req.params.id);
      
      if (!success) {
        return res.status(404).json({ message: "User not found" });
      }

      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
