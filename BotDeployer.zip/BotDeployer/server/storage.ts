import { type User, type InsertUser, type Bot, type InsertBot, type Deployment, type InsertDeployment } from "@shared/schema";
import { randomUUID } from "crypto";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;
  
  getAllBots(): Promise<Bot[]>;
  getBot(id: string): Promise<Bot | undefined>;
  createBot(bot: InsertBot): Promise<Bot>;
  updateBot(id: string, updates: Partial<InsertBot>): Promise<Bot | undefined>;
  deleteBot(id: string): Promise<boolean>;
  
  createDeployment(deployment: InsertDeployment): Promise<Deployment>;
  getUserDeployments(userId: string): Promise<Deployment[]>;
  
  sessionStore: any;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private bots: Map<string, Bot>;
  private deployments: Map<string, Deployment>;
  public sessionStore: any;

  constructor() {
    this.users = new Map();
    this.bots = new Map();
    this.deployments = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      role: insertUser.role || "user",
      botLimit: insertUser.botLimit || 0
    };
    this.users.set(id, user);
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  async getAllBots(): Promise<Bot[]> {
    return Array.from(this.bots.values());
  }

  async getBot(id: string): Promise<Bot | undefined> {
    return this.bots.get(id);
  }

  async createBot(insertBot: InsertBot): Promise<Bot> {
    const id = randomUUID();
    const bot: Bot = { 
      ...insertBot, 
      id,
      description: insertBot.description || null,
      defaultConfig: insertBot.defaultConfig || []
    };
    this.bots.set(id, bot);
    return bot;
  }

  async updateBot(id: string, updates: Partial<InsertBot>): Promise<Bot | undefined> {
    const bot = this.bots.get(id);
    if (!bot) return undefined;
    
    const updatedBot = { ...bot, ...updates };
    this.bots.set(id, updatedBot);
    return updatedBot;
  }

  async deleteBot(id: string): Promise<boolean> {
    return this.bots.delete(id);
  }

  async createDeployment(insertDeployment: InsertDeployment & { url?: string; herokuAppId?: string; status?: string }): Promise<Deployment> {
    const id = randomUUID();
    const deployment: Deployment = { 
      ...insertDeployment, 
      id,
      configUsed: insertDeployment.configUsed || null,
      url: insertDeployment.url || null,
      herokuAppId: insertDeployment.herokuAppId || null,
      status: insertDeployment.status || "deployed",
      createdAt: new Date()
    };
    this.deployments.set(id, deployment);
    return deployment;
  }

  async getUserDeployments(userId: string): Promise<Deployment[]> {
    return Array.from(this.deployments.values()).filter(
      (deployment) => deployment.userId === userId
    );
  }
}

export const storage = new MemStorage();

// Initialize with default admin user
async function initializeStorage() {
  const { scrypt, randomBytes } = await import("crypto");
  const { promisify } = await import("util");
  
  const scryptAsync = promisify(scrypt);
  
  async function hashPassword(password: string) {
    const salt = randomBytes(16).toString("hex");
    const buf = (await scryptAsync(password, salt, 64)) as Buffer;
    return `${buf.toString("hex")}.${salt}`;
  }
  
  // Check if admin user already exists
  const existingAdmin = await storage.getUserByUsername('bandaheali');
  if (!existingAdmin) {
    const hashedPassword = await hashPassword('shaban123');
    
    await storage.createUser({
      username: 'bandaheali',
      password: hashedPassword,
      role: 'admin',
      botLimit: 50
    });
    
    console.log('✅ Default admin user created successfully');
  }
}

// Initialize storage on startup
initializeStorage().catch(console.error);
