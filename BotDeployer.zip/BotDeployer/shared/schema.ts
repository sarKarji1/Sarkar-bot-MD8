import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, jsonb, timestamp, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("user"),
  botLimit: integer("bot_limit").notNull().default(0),
});

export const bots = pgTable("bots", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  repoUrl: text("repo_url").notNull(),
  defaultConfig: jsonb("default_config").default('[]'),
});

export const deployments = pgTable("deployments", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: uuid("user_id").notNull(),
  botId: uuid("bot_id").notNull(),
  appName: text("app_name").notNull(),
  configUsed: jsonb("config_used"),
  url: text("url"),
  herokuAppId: text("heroku_app_id"),
  status: text("status").default("deployed"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertBotSchema = createInsertSchema(bots).omit({
  id: true,
});

export const insertDeploymentSchema = createInsertSchema(deployments).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertBot = z.infer<typeof insertBotSchema>;
export type Bot = typeof bots.$inferSelect;
export type InsertDeployment = z.infer<typeof insertDeploymentSchema>;
export type Deployment = typeof deployments.$inferSelect;
