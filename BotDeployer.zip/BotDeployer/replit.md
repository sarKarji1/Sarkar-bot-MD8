# BotForge - Futuristic Bot Deployment Platform

## Overview

BotForge is a modern full-stack web application for deploying and managing bots with a sleek, futuristic interface. The platform provides role-based access control with separate admin and user dashboards. Admins can manage bot templates and users, while users can deploy bots to Heroku with configurable environment variables. The system features real-time deployment tracking and management capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern React features
- **Routing**: Wouter for lightweight client-side routing with protected routes
- **Styling**: TailwindCSS with custom CSS variables for a dark futuristic theme featuring glassmorphism effects
- **UI Components**: Shadcn/UI component library built on Radix UI primitives for accessibility
- **Animations**: Framer Motion for smooth transitions and interactive elements
- **State Management**: TanStack Query for server state management and caching
- **Forms**: React Hook Form with Zod validation for type-safe form handling

### Backend Architecture
- **Framework**: Express.js with TypeScript for type-safe server development
- **Authentication**: Passport.js with local strategy using bcrypt for password hashing
- **Session Management**: Express sessions with configurable storage (memory store for development)
- **API Design**: RESTful endpoints with role-based access control middleware
- **Validation**: Zod schemas for runtime type validation on API requests
- **Error Handling**: Centralized error handling middleware with structured error responses

### Database Layer
- **ORM**: Drizzle ORM for type-safe database queries and migrations
- **Database**: PostgreSQL via Supabase for cloud-hosted database solution
- **Schema Design**: UUID primary keys, role-based user system, and JSON storage for dynamic bot configurations
- **Migration Strategy**: Drizzle Kit for schema management and database migrations

### Authentication & Authorization
- **Password Security**: bcrypt with salt rounds for secure password hashing
- **Session Management**: Express sessions with configurable storage backends
- **Role-Based Access**: Admin and user roles with different permission levels
- **Protected Routes**: Client-side route protection based on authentication status and user role

### Data Models
- **Users**: Username, hashed password, role (admin/user), and bot deployment limits
- **Bots**: Name, description, repository URL, and dynamic configuration variables stored as JSON
- **Deployments**: User-bot associations with deployment configurations, app names, and timestamps

### User Dashboard Features
- **Bot Deployment**: Users can deploy available bots to Heroku with custom app names
- **Configuration Management**: Dynamic form generation for bot-specific environment variables
- **Deployment Tracking**: View deployment status and access deployed applications
- **Bot Limit Enforcement**: Automatic enforcement of user deployment limits
- **Real-time Updates**: Live status updates and deployment history

### Development Tools
- **Build System**: Vite for fast development builds and hot module replacement
- **TypeScript**: Strict type checking across the entire application
- **Code Quality**: Path aliases for clean imports and component organization
- **Development Server**: Integrated Express and Vite development servers

### Design Patterns
- **Component Architecture**: Reusable UI components with consistent design system
- **Custom Hooks**: useAuth hook for authentication state management
- **Protected Routes**: Higher-order component pattern for route protection
- **Error Boundaries**: Centralized error handling for graceful failure management

## External Dependencies

### Core Framework Dependencies
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight routing library for React
- **framer-motion**: Animation library for smooth UI transitions

### UI Component Libraries
- **@radix-ui/**: Complete suite of accessible UI primitives including dialogs, dropdowns, forms, and navigation components
- **@shadcn/ui**: Pre-built component library built on Radix UI
- **lucide-react**: Icon library for consistent iconography

### Backend Services
- **Supabase**: Cloud PostgreSQL database hosting
- **bcrypt**: Password hashing library
- **passport**: Authentication middleware with local strategy support

### Development Dependencies
- **drizzle-orm**: Type-safe ORM for database operations
- **drizzle-kit**: Database migration and schema management tools
- **zod**: Runtime type validation and schema definition
- **tailwindcss**: Utility-first CSS framework
- **typescript**: Static type checking for JavaScript

### Future Integrations
- **Heroku API**: Planned integration for bot deployment (token already configured)
- **Real-time Monitoring**: Planned for deployment status tracking
- **Analytics Services**: Planned for usage tracking and monitoring