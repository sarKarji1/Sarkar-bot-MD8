# BotForge - Futuristic Bot Deployment Platform

A modern, full-stack web application for deploying and managing bots with a sleek, futuristic interface. Built with React, Express.js, and Supabase PostgreSQL.

## 🚀 Features

### Phase 1 (Current Implementation)
- **Authentication System**: JWT-based auth with bcrypt password hashing
- **Role-Based Access Control**: Admin and User roles with different permissions
- **Admin Dashboard**: 
  - Bot Management (Create, Edit, Delete bots)
  - User Management (Create, Edit, Delete users)
  - Dynamic configuration variables for bots
- **Responsive Design**: Dark mode with glassmorphism effects and smooth animations
- **Toast Notifications**: Real-time feedback for user actions

### Future Phases
- Bot deployment to Heroku
- Real-time deployment monitoring
- User dashboard for bot deployment
- Analytics and usage tracking

## 🛠️ Tech Stack

### Frontend
- **React 18** - Modern UI library
- **TailwindCSS** - Utility-first CSS framework
- **Framer Motion** - Smooth animations
- **Wouter** - Lightweight routing
- **TanStack Query** - Data fetching and caching
- **Shadcn/UI** - High-quality component library

### Backend
- **Express.js** - Web application framework
- **bcrypt** - Password hashing
- **Passport.js** - Authentication middleware
- **Express Session** - Session management

### Database
- **Supabase PostgreSQL** - Cloud-hosted database
- **Drizzle ORM** - Type-safe database queries

## 📦 Installation

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Supabase account

### Local Development

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd botforge
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up Supabase Database**
   - Go to [Supabase Dashboard](https://supabase.com/dashboard/projects)
   - Create a new project
   - Click "Connect" button on the top toolbar
   - Copy the URI from "Connection string" → "Transaction pooler"
   - Replace `[YOUR-PASSWORD]` with your database password

4. **Environment Configuration**
   ```bash
   cp .env.example .env
   ```
   
   Update `.env` with your values:
   ```env
   DATABASE_URL=postgresql://postgres:your-password@db.xxx.supabase.co:5432/postgres
   SESSION_SECRET=your-super-secret-key-here
   ```

5. **Push database schema**
   ```bash
   npm run db:push
   ```

6. **Seed default admin user**
   ```bash
   node seed.js
   