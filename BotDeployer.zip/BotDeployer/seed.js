import bcrypt from 'bcrypt';
import { storage } from './server/storage.js';

async function seed() {
  try {
    console.log('🌱 Starting database seeding...');
    
    // Check if admin user already exists
    const existingAdmin = await storage.getUserByUsername('bandaheali');
    if (existingAdmin) {
      console.log('✅ Admin user already exists, skipping seed');
      return;
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash('shaban123', 10);
    
    // Create default admin user
    const adminUser = await storage.createUser({
      username: 'bandaheali',
      password: hashedPassword,
      role: 'admin',
      botLimit: 50
    });

    console.log('✅ Default admin user created successfully');
    console.log(`   Username: ${adminUser.username}`);
    console.log(`   Role: ${adminUser.role}`);
    console.log(`   Bot Limit: ${adminUser.botLimit}`);
    
  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
}

// Run seed if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  seed();
}

export { seed };
