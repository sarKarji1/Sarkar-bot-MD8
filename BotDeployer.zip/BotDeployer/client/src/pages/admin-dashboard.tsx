import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { Bot, Users, Plus, Edit, Trash2, LogOut, Github, Settings } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Bot as BotType, User as UserType, InsertBot, InsertUser } from "@shared/schema";

export default function AdminDashboard() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [isAddBotOpen, setIsAddBotOpen] = useState(false);
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [selectedBot, setSelectedBot] = useState<BotType | null>(null);
  const [selectedUser, setSelectedUser] = useState<UserType | null>(null);
  
  const [botForm, setBotForm] = useState<InsertBot & { configVariables: Array<{name: string, description: string}> }>({
    name: "",
    description: "",
    repoUrl: "",
    defaultConfig: [],
    configVariables: []
  });
  
  const [userForm, setUserForm] = useState<InsertUser>({
    username: "",
    password: "",
    role: "user",
    botLimit: 5
  });

  // Redirect non-admin users
  if (user?.role !== "admin") {
    setLocation(user?.role === "user" ? "/user" : "/auth");
    return null;
  }

  // Queries
  const { data: bots = [], isLoading: botsLoading } = useQuery<BotType[]>({
    queryKey: ["/api/bots"],
  });

  const { data: users = [], isLoading: usersLoading } = useQuery<UserType[]>({
    queryKey: ["/api/users"],
  });

  // Mutations
  const createBotMutation = useMutation({
    mutationFn: async (data: InsertBot) => {
      const res = await apiRequest("POST", "/api/bots", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      toast({ title: "Success", description: "Bot created successfully" });
      setIsAddBotOpen(false);
      resetBotForm();
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  const createUserMutation = useMutation({
    mutationFn: async (data: InsertUser) => {
      const res = await apiRequest("POST", "/api/register", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "Success", description: "User created successfully" });
      setIsAddUserOpen(false);
      resetUserForm();
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  const deleteBotMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/bots/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bots"] });
      toast({ title: "Success", description: "Bot deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/users/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({ title: "Success", description: "User deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  const resetBotForm = () => {
    setBotForm({
      name: "",
      description: "",
      repoUrl: "",
      defaultConfig: [],
      configVariables: []
    });
  };

  const resetUserForm = () => {
    setUserForm({
      username: "",
      password: "",
      role: "user",
      botLimit: 5
    });
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleCreateBot = (e: React.FormEvent) => {
    e.preventDefault();
    const botData: InsertBot = {
      name: botForm.name,
      description: botForm.description,
      repoUrl: botForm.repoUrl,
      defaultConfig: botForm.configVariables
    };
    createBotMutation.mutate(botData);
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    createUserMutation.mutate(userForm);
  };

  const addConfigVariable = () => {
    setBotForm({
      ...botForm,
      configVariables: [...botForm.configVariables, { name: "", description: "" }]
    });
  };

  const removeConfigVariable = (index: number) => {
    setBotForm({
      ...botForm,
      configVariables: botForm.configVariables.filter((_, i) => i !== index)
    });
  };

  const updateConfigVariable = (index: number, field: "name" | "description", value: string) => {
    const updated = [...botForm.configVariables];
    updated[index][field] = value;
    setBotForm({ ...botForm, configVariables: updated });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-5">
        <div 
          className="absolute inset-0" 
          style={{
            backgroundImage: "radial-gradient(circle at 1px 1px, rgba(14, 165, 233, 0.3) 1px, transparent 0)",
            backgroundSize: "50px 50px"
          }}
        />
      </div>

      {/* Navigation Header */}
      <nav className="glassmorphism border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Bot className="w-8 h-8 text-blue-400 mr-3" />
              <h1 className="text-xl font-bold text-white">BotForge Admin</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-slate-300">{user?.username}</span>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <Tabs defaultValue="bots" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-slate-800 border border-slate-700 mb-8">
            <TabsTrigger value="bots" className="data-[state=active]:bg-blue-600">
              <Bot className="w-4 h-4 mr-2" />
              Bot Management
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-blue-600">
              <Users className="w-4 h-4 mr-2" />
              User Management
            </TabsTrigger>
          </TabsList>

          {/* Bot Management Tab */}
          <TabsContent value="bots">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Bot Management</h2>
              <Dialog open={isAddBotOpen} onOpenChange={setIsAddBotOpen}>
                <DialogTrigger asChild>
                  <Button className="neon-button">
                    <Plus className="w-4 h-4 mr-2" />
                    Add New Bot
                  </Button>
                </DialogTrigger>
                <DialogContent className="glassmorphism border-slate-700 max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="text-white">Add New Bot</DialogTitle>
                    <DialogDescription className="text-slate-400">
                      Create a new bot configuration for deployment
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateBot} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-slate-300">Bot Name *</Label>
                        <Input
                          value={botForm.name}
                          onChange={(e) => setBotForm({ ...botForm, name: e.target.value })}
                          className="cyber-input mt-2"
                          placeholder="e.g., Discord Moderation Bot"
                          required
                        />
                      </div>
                      <div>
                        <Label className="text-slate-300">Repository URL *</Label>
                        <Input
                          type="url"
                          value={botForm.repoUrl}
                          onChange={(e) => setBotForm({ ...botForm, repoUrl: e.target.value })}
                          className="cyber-input mt-2"
                          placeholder="https://github.com/user/repo"
                          required
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-slate-300">Description</Label>
                      <Textarea
                        value={botForm.description || ""}
                        onChange={(e) => setBotForm({ ...botForm, description: e.target.value })}
                        className="cyber-input mt-2"
                        placeholder="Brief description of what this bot does..."
                      />
                    </div>

                    <div>
                      <div className="flex justify-between items-center mb-4">
                        <Label className="text-slate-300">Configuration Variables</Label>
                        <Button type="button" variant="outline" size="sm" onClick={addConfigVariable}>
                          <Plus className="w-4 h-4 mr-1" />
                          Add Variable
                        </Button>
                      </div>
                      
                      <div className="space-y-4">
                        {botForm.configVariables.map((variable, index) => (
                          <div key={index} className="glassmorphism rounded-lg p-4 border border-slate-600">
                            <div className="flex justify-between items-start mb-3">
                              <span className="text-sm text-slate-400">Variable #{index + 1}</span>
                              <Button 
                                type="button" 
                                variant="ghost" 
                                size="sm"
                                onClick={() => removeConfigVariable(index)}
                                className="text-red-400 hover:text-red-300"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <Label className="text-xs text-slate-400">Variable Name</Label>
                                <Input
                                  value={variable.name}
                                  onChange={(e) => updateConfigVariable(index, "name", e.target.value)}
                                  className="cyber-input mt-1"
                                  placeholder="e.g., DISCORD_TOKEN"
                                />
                              </div>
                              <div>
                                <Label className="text-xs text-slate-400">Description</Label>
                                <Input
                                  value={variable.description}
                                  onChange={(e) => updateConfigVariable(index, "description", e.target.value)}
                                  className="cyber-input mt-1"
                                  placeholder="e.g., Bot authentication token"
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setIsAddBotOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" className="neon-button" disabled={createBotMutation.isPending}>
                        {createBotMutation.isPending ? "Creating..." : "Create Bot"}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Bots Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {bots.map((bot, index) => (
                <motion.div
                  key={bot.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Card className="glassmorphism border-slate-700 hover:scale-105 transition-transform duration-300">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                            <Bot className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <CardTitle className="text-white">{bot.name}</CardTitle>
                            <CardDescription className="text-slate-400">
                              {bot.description || "No description"}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm" className="text-slate-400 hover:text-blue-400">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-slate-400 hover:text-red-400"
                            onClick={() => deleteBotMutation.mutate(bot.id)}
                            disabled={deleteBotMutation.isPending}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex items-center text-xs text-slate-500">
                          <Github className="w-3 h-3 mr-1" />
                          <span className="truncate">{bot.repoUrl}</span>
                        </div>
                        <div className="text-xs text-slate-400">
                          <Settings className="w-3 h-3 inline mr-1" />
                          Config Variables: {Array.isArray(bot.defaultConfig) ? bot.defaultConfig.length : 0}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="users">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">User Management</h2>
              <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
                <DialogTrigger asChild>
                  <Button className="neon-button">
                    <Plus className="w-4 h-4 mr-2" />
                    Add New User
                  </Button>
                </DialogTrigger>
                <DialogContent className="glassmorphism border-slate-700">
                  <DialogHeader>
                    <DialogTitle className="text-white">Add New User</DialogTitle>
                    <DialogDescription className="text-slate-400">
                      Create a new user account
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreateUser} className="space-y-6">
                    <div>
                      <Label className="text-slate-300">Username *</Label>
                      <Input
                        value={userForm.username}
                        onChange={(e) => setUserForm({ ...userForm, username: e.target.value })}
                        className="cyber-input mt-2"
                        placeholder="Enter username"
                        required
                      />
                    </div>

                    <div>
                      <Label className="text-slate-300">Password *</Label>
                      <Input
                        type="password"
                        value={userForm.password}
                        onChange={(e) => setUserForm({ ...userForm, password: e.target.value })}
                        className="cyber-input mt-2"
                        placeholder="Enter password"
                        required
                      />
                    </div>

                    <div>
                      <Label className="text-slate-300">Role *</Label>
                      <Select 
                        value={userForm.role} 
                        onValueChange={(value: "user" | "admin") => setUserForm({ ...userForm, role: value })}
                      >
                        <SelectTrigger className="cyber-input mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-800 border-slate-700">
                          <SelectItem value="user">User</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label className="text-slate-300">Bot Limit *</Label>
                      <Input
                        type="number"
                        min="0"
                        max="50"
                        value={userForm.botLimit}
                        onChange={(e) => setUserForm({ ...userForm, botLimit: parseInt(e.target.value) })}
                        className="cyber-input mt-2"
                        placeholder="Maximum number of bots (0-50)"
                        required
                      />
                    </div>

                    <DialogFooter>
                      <Button type="button" variant="outline" onClick={() => setIsAddUserOpen(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" className="neon-button" disabled={createUserMutation.isPending}>
                        {createUserMutation.isPending ? "Creating..." : "Create User"}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* Users Table */}
            <Card className="glassmorphism border-slate-700">
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-700">
                      <TableHead className="text-slate-300">User</TableHead>
                      <TableHead className="text-slate-300">Role</TableHead>
                      <TableHead className="text-slate-300">Bot Limit</TableHead>
                      <TableHead className="text-slate-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id} className="border-slate-700 hover:bg-slate-800">
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                              <Users className="w-4 h-4 text-white" />
                            </div>
                            <span className="text-white font-medium">{user.username}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={user.role === "admin" ? "default" : "secondary"}
                            className={user.role === "admin" ? "bg-purple-600" : "bg-green-600"}
                          >
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-slate-300">{user.botLimit}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="ghost" size="sm" className="text-blue-400 hover:text-blue-300">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-red-400 hover:text-red-300"
                              onClick={() => deleteUserMutation.mutate(user.id)}
                              disabled={deleteUserMutation.isPending}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
