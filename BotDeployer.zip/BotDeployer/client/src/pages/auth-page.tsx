import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";
import { Bot, Lock, User, Mail, MessageSquare } from "lucide-react";

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [, setLocation] = useLocation();
  
  const [loginForm, setLoginForm] = useState({ username: "", password: "" });
  const [registerForm, setRegisterForm] = useState({ 
    username: "", 
    password: "", 
    role: "user" as "user" | "admin",
    botLimit: 5 
  });

  // Redirect if already logged in
  if (user) {
    setLocation(user.role === "admin" ? "/admin" : "/user");
    return null;
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await loginMutation.mutateAsync(loginForm);
    } catch (error) {
      // Error handling done in mutation
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await registerMutation.mutateAsync(registerForm);
    } catch (error) {
      // Error handling done in mutation
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-5">
        <div 
          className="absolute inset-0" 
          style={{
            backgroundImage: "radial-gradient(circle at 1px 1px, rgba(14, 165, 233, 0.3) 1px, transparent 0)",
            backgroundSize: "50px 50px"
          }}
        />
      </div>

      {/* Left Side - Forms */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <div className="glassmorphism rounded-2xl p-8 shadow-2xl">
            {/* Logo Section */}
            <div className="text-center mb-8">
              <motion.div 
                className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 mb-4"
                animate={{ rotate: [0, 5, -5, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <Bot className="w-8 h-8 text-white" />
              </motion.div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                BotForge
              </h1>
              <p className="text-slate-400 mt-2">Futuristic Bot Deployment Platform</p>
            </div>

            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-slate-800 border border-slate-700">
                <TabsTrigger value="login" className="data-[state=active]:bg-blue-600">Login</TabsTrigger>
                <TabsTrigger value="register" className="data-[state=active]:bg-blue-600">Register</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login" className="mt-6">
                <form onSubmit={handleLogin} className="space-y-6">
                  <div>
                    <Label className="text-slate-300 flex items-center gap-2">
                      <User className="w-4 h-4 text-blue-400" />
                      Username
                    </Label>
                    <Input
                      type="text"
                      value={loginForm.username}
                      onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                      className="cyber-input mt-2"
                      placeholder="Enter your username"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label className="text-slate-300 flex items-center gap-2">
                      <Lock className="w-4 h-4 text-blue-400" />
                      Password
                    </Label>
                    <Input
                      type="password"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                      className="cyber-input mt-2"
                      placeholder="Enter your password"
                      required
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="neon-button w-full"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? "Accessing..." : "Access System"}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="register" className="mt-6">
                <form onSubmit={handleRegister} className="space-y-6">
                  <div>
                    <Label className="text-slate-300 flex items-center gap-2">
                      <User className="w-4 h-4 text-blue-400" />
                      Username
                    </Label>
                    <Input
                      type="text"
                      value={registerForm.username}
                      onChange={(e) => setRegisterForm({ ...registerForm, username: e.target.value })}
                      className="cyber-input mt-2"
                      placeholder="Choose a username"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label className="text-slate-300 flex items-center gap-2">
                      <Lock className="w-4 h-4 text-blue-400" />
                      Password
                    </Label>
                    <Input
                      type="password"
                      value={registerForm.password}
                      onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
                      className="cyber-input mt-2"
                      placeholder="Create a password"
                      required
                    />
                  </div>



                  <Button 
                    type="submit" 
                    className="neon-button w-full"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>

            {/* Contact Section */}
            <div className="mt-8 text-center border-t border-slate-700 pt-6">
              <p className="text-slate-400 text-sm mb-4">Need access to this platform?</p>
              <div className="flex gap-3 justify-center">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="border-green-600 text-green-400 hover:bg-green-600 hover:text-white"
                  asChild
                >
                  <a href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
                    <MessageSquare className="w-4 h-4 mr-2" />
                    WhatsApp
                  </a>
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="border-slate-600 text-slate-400 hover:bg-slate-600 hover:text-white"
                  asChild
                >
                  <a href="mailto:admin@botforge.com">
                    <Mail className="w-4 h-4 mr-2" />
                    Email
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Right Side - Hero */}
      <div className="hidden lg:flex lg:w-1/2 items-center justify-center p-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-center"
        >
          <div className="glassmorphism rounded-2xl p-12">
            <h2 className="text-4xl font-bold text-white mb-6">
              Deploy Bots with
              <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent"> Ease</span>
            </h2>
            <p className="text-slate-300 text-lg mb-8 leading-relaxed">
              Experience the future of bot deployment with our advanced platform. 
              Manage, deploy, and scale your bots effortlessly with enterprise-grade security.
            </p>
            <div className="grid grid-cols-1 gap-4 text-left">
              <div className="flex items-center gap-3 text-slate-300">
                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                One-click deployment to Heroku
              </div>
              <div className="flex items-center gap-3 text-slate-300">
                <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                Dynamic configuration management
              </div>
              <div className="flex items-center gap-3 text-slate-300">
                <div className="w-2 h-2 bg-cyan-400 rounded-full"></div>
                Role-based access control
              </div>
              <div className="flex items-center gap-3 text-slate-300">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                Real-time monitoring & analytics
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
