import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import { Bot, LogOut, Rocket, ExternalLink, Clock, CheckCircle, AlertCircle, Plus, Github, Settings } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Bot as BotType, Deployment as DeploymentType } from "@shared/schema";

export default function UserDashboard() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [isDeployOpen, setIsDeployOpen] = useState(false);
  const [selectedBot, setSelectedBot] = useState<BotType | null>(null);
  const [deployForm, setDeployForm] = useState({
    appName: "",
    configValues: {} as Record<string, string>
  });

  // Redirect non-user to appropriate page
  if (user?.role !== "user") {
    setLocation(user?.role === "admin" ? "/admin" : "/auth");
    return null;
  }

  // Queries
  const { data: bots = [], isLoading: botsLoading } = useQuery<BotType[]>({
    queryKey: ["/api/bots"],
  });

  const { data: deployments = [], isLoading: deploymentsLoading } = useQuery<DeploymentType[]>({
    queryKey: ["/api/deployments"],
  });

  // Mutation
  const deployBotMutation = useMutation({
    mutationFn: async (data: { botId: string; appName: string; configValues: Record<string, string> }) => {
      const res = await apiRequest("POST", "/api/deploy", data);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/deployments"] });
      toast({ 
        title: "Success", 
        description: `Bot deployed to ${data.url}`,
      });
      setIsDeployOpen(false);
      resetDeployForm();
    },
    onError: (error: Error) => {
      toast({ 
        title: "Deployment Failed", 
        description: error.message, 
        variant: "destructive" 
      });
    }
  });

  const resetDeployForm = () => {
    setDeployForm({ appName: "", configValues: {} });
    setSelectedBot(null);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleDeploy = (bot: BotType) => {
    setSelectedBot(bot);
    setDeployForm({
      appName: "",
      configValues: {}
    });
    setIsDeployOpen(true);
  };

  const handleDeploySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBot) return;

    deployBotMutation.mutate({
      botId: selectedBot.id,
      appName: deployForm.appName,
      configValues: deployForm.configValues
    });
  };

  const updateConfigValue = (key: string, value: string) => {
    setDeployForm({
      ...deployForm,
      configValues: { ...deployForm.configValues, [key]: value }
    });
  };

  const getDeploymentStatus = (deployment: DeploymentType) => {
    // For now, all deployments are considered successful
    return "deployed";
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "deployed":
        return <Badge className="bg-green-600 text-white"><CheckCircle className="w-3 h-3 mr-1" />Deployed</Badge>;
      case "deploying":
        return <Badge className="bg-yellow-600 text-white"><Clock className="w-3 h-3 mr-1" />Deploying</Badge>;
      case "failed":
        return <Badge className="bg-red-600 text-white"><AlertCircle className="w-3 h-3 mr-1" />Failed</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-5">
        <div 
          className="absolute inset-0" 
          style={{
            backgroundImage: "radial-gradient(circle at 1px 1px, rgba(14, 165, 233, 0.3) 1px, transparent 0)",
            backgroundSize: "50px 50px"
          }}
        />
      </div>

      {/* Navigation Header */}
      <nav className="glassmorphism border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Bot className="w-8 h-8 text-blue-400 mr-3" />
              <h1 className="text-xl font-bold text-white">BotForge</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="text-sm text-slate-300">
                <span className="font-medium">{user?.username}</span>
                <span className="ml-2 text-slate-400">({deployments.length}/{user?.botLimit} bots)</span>
              </div>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        <Tabs defaultValue="deploy" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-slate-800 border border-slate-700 mb-8">
            <TabsTrigger value="deploy" className="data-[state=active]:bg-blue-600">
              <Rocket className="w-4 h-4 mr-2" />
              Deploy Bots
            </TabsTrigger>
            <TabsTrigger value="deployments" className="data-[state=active]:bg-blue-600">
              <Settings className="w-4 h-4 mr-2" />
              My Deployments
            </TabsTrigger>
          </TabsList>

          {/* Deploy Bots Tab */}
          <TabsContent value="deploy">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Available Bots</h2>
              <div className="text-slate-400">
                {deployments.length}/{user?.botLimit} bots deployed
              </div>
            </div>

            {botsLoading ? (
              <div className="text-center text-slate-400 py-12">Loading bots...</div>
            ) : bots.length === 0 ? (
              <Card className="glassmorphism border-slate-700 text-center py-12">
                <CardContent>
                  <Bot className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <h3 className="text-xl text-white mb-2">No Bots Available</h3>
                  <p className="text-slate-400">No bots have been added by the admin yet.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {bots.map((bot, index) => (
                  <motion.div
                    key={bot.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                  >
                    <Card className="glassmorphism border-slate-700 hover:scale-105 transition-transform duration-300">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                              <Bot className="w-6 h-6 text-white" />
                            </div>
                            <div>
                              <CardTitle className="text-white">{bot.name}</CardTitle>
                              <CardDescription className="text-slate-400">
                                {bot.description || "No description"}
                              </CardDescription>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex items-center text-xs text-slate-400">
                            <Github className="w-3 h-3 mr-1" />
                            <span className="truncate">{bot.repoUrl}</span>
                          </div>
                          
                          {Array.isArray(bot.defaultConfig) && bot.defaultConfig.length > 0 && (
                            <div>
                              <span className="text-xs text-slate-500">Config Variables:</span>
                              <div className="flex flex-wrap gap-1 mt-1">
                                {bot.defaultConfig.slice(0, 3).map((config: any, idx: number) => (
                                  <Badge key={idx} variant="outline" className="text-xs">
                                    {config.name || `var${idx + 1}`}
                                  </Badge>
                                ))}
                                {bot.defaultConfig.length > 3 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{bot.defaultConfig.length - 3} more
                                  </Badge>
                                )}
                              </div>
                            </div>
                          )}

                          <Button 
                            onClick={() => handleDeploy(bot)}
                            className="w-full neon-button"
                            disabled={deployments.length >= user!.botLimit}
                          >
                            <Rocket className="w-4 h-4 mr-2" />
                            {deployments.length >= user!.botLimit ? "Limit Reached" : "Deploy Bot"}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </TabsContent>

          {/* My Deployments Tab */}
          <TabsContent value="deployments">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">My Deployments</h2>
            </div>

            {deploymentsLoading ? (
              <div className="text-center text-slate-400 py-12">Loading deployments...</div>
            ) : deployments.length === 0 ? (
              <Card className="glassmorphism border-slate-700 text-center py-12">
                <CardContent>
                  <Rocket className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <h3 className="text-xl text-white mb-2">No Deployments Yet</h3>
                  <p className="text-slate-400">Deploy your first bot to get started!</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {deployments.map((deployment, index) => {
                  const bot = bots.find(b => b.id === deployment.botId);
                  const status = getDeploymentStatus(deployment);
                  
                  return (
                    <motion.div
                      key={deployment.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <Card className="glassmorphism border-slate-700">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div>
                              <CardTitle className="text-white flex items-center gap-2">
                                {bot?.name || "Unknown Bot"}
                                {getStatusBadge(status)}
                              </CardTitle>
                              <CardDescription className="text-slate-400">
                                {deployment.appName}
                              </CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between text-sm">
                              <span className="text-slate-400">Deployed:</span>
                              <span className="text-slate-300">
                                {new Date(deployment.createdAt || '').toLocaleDateString()}
                              </span>
                            </div>
                            
                            {status === "deployed" && (
                              <Button
                                variant="outline" 
                                size="sm" 
                                className="w-full"
                                asChild
                              >
                                <a 
                                  href={deployment.url || `https://${deployment.appName}.herokuapp.com`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  <ExternalLink className="w-4 h-4 mr-2" />
                                  Open App
                                </a>
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Deploy Bot Dialog */}
        <Dialog open={isDeployOpen} onOpenChange={setIsDeployOpen}>
          <DialogContent className="glassmorphism border-slate-700 max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">Deploy {selectedBot?.name}</DialogTitle>
              <DialogDescription className="text-slate-400">
                Configure your bot deployment settings
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleDeploySubmit} className="space-y-6">
              <div>
                <Label className="text-slate-300">Heroku App Name *</Label>
                <Input
                  value={deployForm.appName}
                  onChange={(e) => setDeployForm({ ...deployForm, appName: e.target.value.toLowerCase() })}
                  className="cyber-input mt-2"
                  placeholder="my-awesome-bot-123"
                  pattern="^[a-z][a-z0-9-]{2,29}$"
                  title="App name must be 3-30 characters, start with a letter, and contain only lowercase letters, numbers, and hyphens"
                  required
                />
                <p className="text-xs text-slate-500 mt-1">
                  Must be 3-30 characters, unique on Heroku, start with a letter. Only lowercase letters, numbers, and hyphens allowed.
                </p>
              </div>

              {selectedBot && Array.isArray(selectedBot.defaultConfig) && selectedBot.defaultConfig.length > 0 && (
                <div>
                  <Label className="text-slate-300 mb-4 block">Configuration Variables</Label>
                  <div className="space-y-4">
                    {selectedBot.defaultConfig.map((config: any, index: number) => (
                      <div key={index} className="glassmorphism rounded-lg p-4 border border-slate-600">
                        <div className="space-y-2">
                          <Label className="text-sm text-slate-300">{config.name || `Variable ${index + 1}`}</Label>
                          {config.description && (
                            <p className="text-xs text-slate-500">{config.description}</p>
                          )}
                          <Input
                            value={deployForm.configValues[config.name || `var${index}`] || ""}
                            onChange={(e) => updateConfigValue(config.name || `var${index}`, e.target.value)}
                            className="cyber-input"
                            placeholder={`Enter ${config.name || 'value'}`}
                            type={config.name?.toLowerCase().includes('token') || config.name?.toLowerCase().includes('key') || config.name?.toLowerCase().includes('secret') ? 'password' : 'text'}
                            required
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDeployOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="neon-button" disabled={deployBotMutation.isPending}>
                  {deployBotMutation.isPending ? "Deploying..." : "Deploy to Heroku"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}